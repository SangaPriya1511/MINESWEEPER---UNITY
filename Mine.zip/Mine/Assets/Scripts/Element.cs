﻿using UnityEngine;
using System.Collections;


public class Element : MonoBehaviour
{

    public bool mine;
   

    
    public Sprite[] emptyTextures;
    public Sprite mineTexture;
    
    void Start ()
    {
        mine = Random.value < 0.15;

        int x = (int)transform.position.x;
        int y = (int)transform.position.y;
        Grid1.elements[x, y] = this;
    }

    

    public void loadTexture(int adjacentCount)
    {
        if (mine)
            GetComponent<SpriteRenderer> ().sprite = mineTexture;
        else
            GetComponent<SpriteRenderer>().sprite = emptyTextures[adjacentCount];
    }

    public bool isCovered()
    {
        return GetComponent<SpriteRenderer> ().sprite.texture.name == "Default";
    }
    
    void OnMouseUpAsButton()
    {
        if (mine)
        {
            Grid1.uncoverMines ();
            print("You Lose");

        }
        else
        {
            int x = (int)transform.position.x;
            int y = (int)transform.position.y;
            loadTexture(Grid1.adjacentMines(x, y));

            Grid1.FFuncover(x, y, new bool[Grid1.w, Grid1.h]);

            if (Grid1.GetisFinished())
                print("You win");


        }
    }
}

    
        
